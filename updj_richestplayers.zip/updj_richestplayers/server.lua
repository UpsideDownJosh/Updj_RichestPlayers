local Framework = nil
local FrameworkType = nil

-- ============================================================
-- Framework Detection
-- ============================================================
CreateThread(function()
    local fw = Config.Framework

    if fw == 'auto' then
        if GetResourceState('es_extended') == 'started' then
            fw = 'esx'
        elseif GetResourceState('qb-core') == 'started' then
            fw = 'qbcore'
        end
    end

    if fw == 'esx' then
        FrameworkType = 'esx'
        Framework = exports['es_extended']:getSharedObject()
    elseif fw == 'qbcore' then
        FrameworkType = 'qbcore'
        Framework = exports['qb-core']:GetCoreObject()
    else
        print('^1[updj_richleaderboard] No supported framework detected. Set Config.Framework manually.^0')
    end
end)

-- ============================================================
-- Number formatting helper (1234567 -> 1,234,567)
-- ============================================================
local function formatMoney(amount)
    local formatted = tostring(math.floor(amount or 0))
    local k
    while true do
        formatted, k = formatted:gsub('^(-?%d+)(%d%d%d)', '%1,%2')
        if k == 0 then break end
    end
    return formatted
end

-- ============================================================
-- Fetch wealth data (ESX)
-- ============================================================
local function getRichListESX(cb)
    if Config.Mode == 'database' then
        local query = [[
            SELECT firstname, lastname,
                   COALESCE(JSON_EXTRACT(accounts, '$.money'), 0) +
                   COALESCE(JSON_EXTRACT(accounts, '$.bank'), 0) AS total
            FROM users
            ORDER BY total DESC
            LIMIT ?
        ]]
        MySQL.query(query, { Config.TopCount }, function(result)
            local list = {}
            if result then
                for _, row in ipairs(result) do
                    list[#list+1] = {
                        name = ('%s %s'):format(row.firstname or 'Unknown', row.lastname or ''),
                        total = tonumber(row.total) or 0
                    }
                end
            end
            cb(list)
        end)
    else
        local players = {}
        for _, playerId in ipairs(GetPlayers()) do
            local xPlayer = Framework.GetPlayerFromId(playerId)
            if xPlayer then
                local money = xPlayer.getAccount('money')
                local bank = xPlayer.getAccount('bank')
                local total = ((money and money.money) or 0) + ((bank and bank.money) or 0)
                players[#players+1] = {
                    name = xPlayer.getName(),
                    total = total
                }
            end
        end
        table.sort(players, function(a, b) return a.total > b.total end)
        local list = {}
        for i = 1, math.min(Config.TopCount, #players) do
            list[i] = players[i]
        end
        cb(list)
    end
end

-- ============================================================
-- Fetch wealth data (QBCore)
-- ============================================================
local function getRichListQB(cb)
    if Config.Mode == 'database' then
        local query = [[
            SELECT charinfo, money
            FROM players
        ]]
        MySQL.query(query, {}, function(result)
            local list = {}
            if result then
                for _, row in ipairs(result) do
                    local money = json.decode(row.money) or {}
                    local charinfo = json.decode(row.charinfo) or {}
                    local total = (money.cash or 0) + (money.bank or 0)
                    list[#list+1] = {
                        name = ('%s %s'):format(charinfo.firstname or 'Unknown', charinfo.lastname or ''),
                        total = total
                    }
                end
            end
            table.sort(list, function(a, b) return a.total > b.total end)
            local trimmed = {}
            for i = 1, math.min(Config.TopCount, #list) do
                trimmed[i] = list[i]
            end
            cb(trimmed)
        end)
    else
        local players = {}
        for _, playerId in ipairs(GetPlayers()) do
            local Player = Framework.Functions.GetPlayer(tonumber(playerId))
            if Player then
                local total = (Player.PlayerData.money.cash or 0) + (Player.PlayerData.money.bank or 0)
                local ci = Player.PlayerData.charinfo
                players[#players+1] = {
                    name = ('%s %s'):format(ci.firstname or 'Unknown', ci.lastname or ''),
                    total = total
                }
            end
        end
        table.sort(players, function(a, b) return a.total > b.total end)
        local list = {}
        for i = 1, math.min(Config.TopCount, #players) do
            list[i] = players[i]
        end
        cb(list)
    end
end

-- ============================================================
-- Build & send the Discord embed
-- ============================================================
local function sendLeaderboard(list)
    if not Config.Webhook or Config.Webhook == 'PASTE_YOUR_WEBHOOK_URL_HERE' then
        print('^1[updj_richleaderboard] Webhook not configured.^0')
        return
    end

    local description
    if #list == 0 then
        description = 'No player wealth data available.'
    else
        local lines = {}
        local medals = { '🥇', '🥈', '🥉' }
        for i, entry in ipairs(list) do
            local rank = medals[i] or ('**#' .. i .. '**')
            lines[#lines+1] = ('%s %s — $%s'):format(rank, entry.name, formatMoney(entry.total))
        end
        description = table.concat(lines, '\n')
    end

    local embed = {
        {
            title = Config.Embed.title,
            description = description,
            color = Config.Embed.color,
            footer = { text = Config.Embed.footer },
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ')
        }
    }

    PerformHttpRequest(Config.Webhook, function(err) end, 'POST', json.encode({
        username = Config.Embed.botName,
        avatar_url = Config.Embed.botAvatar ~= '' and Config.Embed.botAvatar or nil,
        embeds = embed
    }), { ['Content-Type'] = 'application/json' })
end

-- ============================================================
-- Run the leaderboard
-- ============================================================
local function runLeaderboard()
    if not FrameworkType then return end
    local handler = FrameworkType == 'esx' and getRichListESX or getRichListQB
    handler(function(list)
        sendLeaderboard(list)
    end)
end

-- ============================================================
-- Auto interval loop
-- ============================================================
CreateThread(function()
    while FrameworkType == nil do Wait(1000) end
    Wait(5000) -- let everything settle on boot
    while true do
        runLeaderboard()
        Wait(Config.Interval * 60 * 1000)
    end
end)

-- ============================================================
-- Manual admin command
-- ============================================================
RegisterCommand(Config.Command, function(source, args, raw)
    if source ~= 0 then
        if not IsPlayerAceAllowed(source, 'updj.leaderboard') then
            return
        end
    end
    runLeaderboard()
    if source ~= 0 then
        print(('^2[updj_richleaderboard] %s triggered the leaderboard manually.^0'):format(source))
    end
end, false)