fx_version 'cerulean'
game 'gta5'

author 'UPDJ Developmentz'
description 'updj_richleaderboard - Richest Player Leaderboard with Discord logging'
version '1.0.0'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'config.lua',
    'server.lua'
}

