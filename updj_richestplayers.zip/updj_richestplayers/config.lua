Config = {}

-- Framework: 'esx', 'qbcore', or 'auto'
Config.Framework = 'auto'

-- Discord webhook URL (paste yours here)
Config.Webhook = 'PASTE_YOUR_WEBHOOK_URL_HERE'

-- How often to post the leaderboard (in minutes)
Config.Interval = 30

-- How many players to show on the leaderboard
Config.TopCount = 10

-- Count only online players, or pull everyone from the database
-- 'online' = currently connected players only
-- 'database' = all characters stored in the DB
Config.Mode = 'database'

-- Embed appearance
Config.Embed = {
    title = '💰 Richest Players Leaderboard',
    color = 16766720, -- gold
    botName = 'UPDJ Leaderboard',
    botAvatar = '', -- optional avatar URL
    footer = 'UPDJ Developmentz'
}

-- Manual command to trigger the leaderboard (admin only via ACE perm 'updj.leaderboard')
Config.Command = 'richlist'